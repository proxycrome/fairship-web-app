import React from 'react';

const Settings = () => {
  return (
    <div className="page-content">
      <h5 className="text-center"> Settings </h5>
    </div>
  );
};

export default Settings;
