import React from 'react';

const Service = () => {
  return (
    <div className="page-content">
      <h5 className="text-center"> Service </h5>
    </div>
  );
};

export default Service;
