import React from 'react';

const Chats = () => {
  return (
    <div className="page-content">
      <h5 className="text-center"> Chats </h5>
    </div>
  );
};

export default Chats;
