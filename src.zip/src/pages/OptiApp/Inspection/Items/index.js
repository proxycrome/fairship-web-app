import React from 'react';

const Items = () => {
  return (
    <div className="page-content">
      <h5 className="text-center"> Items </h5>
    </div>
  );
};

export default Items;
