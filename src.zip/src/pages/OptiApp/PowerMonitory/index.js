import React from 'react';

const PowerMonitor = () => {
  return <div className="page-content">Power Monitor</div>;
};

export default PowerMonitor;
